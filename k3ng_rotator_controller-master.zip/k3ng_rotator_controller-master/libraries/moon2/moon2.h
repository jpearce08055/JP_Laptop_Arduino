void grid2deg(char *grid0,double *dlong,double *dlat);

void moon2(int y,int m,int Day,
  double UT,
  double lon,double lat,
  double *RA,double *Dec,
  double *topRA,double *topDec,
  double *LST,double *HA,
  double *Az,double *El,double *dist);
